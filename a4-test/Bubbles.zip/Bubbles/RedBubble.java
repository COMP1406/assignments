public class RedBubble extends Bubble{
 
	/* constructor */
	public RedBubble(int x, int y, double radius){
		super(x,y,radius);
	}
	
	
	/** the brain behind the bubble
	 *
	 * @param bubbles contains all bubbles in the world
	 * @param x1 is x-coordinate of upper left corner boundary
	 * @param y1 is y-coordinate of upper left corner boundary
	 * @param x2 is x-coordinate of lower right corner boundary
	 * @param y2 is y-coordinate of lower right corner boundary 
   */	 
	public void applyLogic(Bubble[] bubbles, int x1, int y1, int x2, int y2){
	}
	
	/** updates current bubble object */
	public void update(){

		this.capSpeed(MAX_SPEED);
		this.x = (int) (this.x + this.speedX);
		this.y = (int) (this.y + this.speedY);
	}
}